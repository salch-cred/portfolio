# Samad's Portfolio Website

## Project info

**URL**: https://samad.lol

## How can I edit this code?

There are several ways to edit this application.

**Use your preferred IDE**

You can work locally using your own IDE. Clone this repo and push changes as needed.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

You can deploy this project using various platforms:

- **Vercel**: `vercel --prod`
- **Netlify**: `netlify deploy --prod`
- **Firebase**: `firebase deploy`

See the DOMAIN_SETUP_GUIDE.md for detailed deployment instructions.

## Custom Domain Setup

This project is configured to work with the custom domain: **samad.lol**

For complete setup instructions, see the deployment guides included in this repository.
