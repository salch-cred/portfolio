import { Section } from "./ui/Section";
import { Heading } from "./ui/Heading";
import { GlassCard } from "./ui/GlassCard";
import { content } from "@/data/content";
import { CheckCircle } from "lucide-react";

export const SkillsSection = () => {
  return (
    <Section id="skills">
      <Heading>My Expertise</Heading>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {content.skills.map((skill, i) => (
          <GlassCard key={i} delay={i * 0.08}>
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center mb-6 border border-white/5">
              <skill.icon className="text-indigo-400" size={28} />
            </div>
            <h3 className="text-xl font-bold text-white mb-6">{skill.category}</h3>
            <ul className="space-y-4">
              {skill.items.map((item, j) => (
                <li key={j} className="flex items-start gap-3 text-sm text-slate-400 font-medium">
                  <CheckCircle size={18} className="text-indigo-500 mt-0.5 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </GlassCard>
        ))}
      </div>
    </Section>
  );
};
