import { motion as m, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

interface ProofOfWork {
  title: string;
  desc: string;
  images?: string[];
}

interface GalleryModalProps {
  activeProof: ProofOfWork | null;
  onClose: () => void;
}

export const GalleryModal = ({ activeProof, onClose }: GalleryModalProps) => {
  return (
    <AnimatePresence>
      {activeProof && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <m.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/95"
            style={{ backdropFilter: 'blur(8px)' }}
          />
          <m.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-6xl max-h-[90vh] bg-background border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl overflow-y-auto"
          >
            <div className="flex justify-between items-start mb-12">
              <div>
                <h3 className="text-4xl font-bold text-white mb-2">{activeProof.title}</h3>
                <p className="text-slate-400 text-xl">{activeProof.desc}</p>
              </div>
              <button
                onClick={onClose}
                className="p-4 rounded-full bg-white/5 hover:bg-white/10 text-white smooth-transition border border-white/5 hover:border-white/20"
              >
                <X size={28} />
              </button>
            </div>
            <div className="grid md:grid-cols-2 gap-10">
              {activeProof.images && activeProof.images.map((img, idx) => (
                <div key={idx} className="rounded-3xl overflow-hidden border border-white/10 shadow-2xl bg-black">
                  <img src={img} alt={`${activeProof.title} Screenshot ${idx + 1}`} className="w-full h-auto" loading="lazy" />
                </div>
              ))}
            </div>
          </m.div>
        </div>
      )}
    </AnimatePresence>
  );
};
