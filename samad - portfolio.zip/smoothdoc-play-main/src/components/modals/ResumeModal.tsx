import { motion as m, AnimatePresence } from "framer-motion";
import { X, Eye, Download, ArrowRight } from "lucide-react";

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal = ({ isOpen, onClose }: ResumeModalProps) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <m.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/90"
            style={{ backdropFilter: 'blur(8px)' }}
          />
          <m.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-md bg-background border border-white/10 rounded-3xl p-8 shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white smooth-transition"
            >
              <X size={20} />
            </button>
            <h3 className="text-3xl font-bold text-white mb-2 text-center">Resume Options</h3>
            <p className="text-slate-400 text-center mb-8">How would you like to view my resume?</p>
            <div className="grid gap-4">
              <a
                href="https://drive.google.com/file/d/1g408i-u_TbrbbXw18iyiwIh9EjtxFNrl/view?usp=drive_link"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-indigo-500/10 smooth-transition group"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-500/20 rounded-xl text-indigo-400 group-hover:text-white smooth-transition">
                    <Eye size={24} />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-white">View Online</div>
                    <div className="text-xs text-slate-400">Open in Google Drive</div>
                  </div>
                </div>
                <ArrowRight size={20} className="text-slate-500 group-hover:text-white smooth-transition" />
              </a>
              <a
                href="https://drive.google.com/uc?export=download&id=1g408i-u_TbrbbXw18iyiwIh9EjtxFNrl"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/50 hover:bg-purple-500/10 smooth-transition group"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-purple-500/20 rounded-xl text-purple-400 group-hover:text-white smooth-transition">
                    <Download size={24} />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-white">Download PDF</div>
                    <div className="text-xs text-slate-400">Save to your device</div>
                  </div>
                </div>
                <ArrowRight size={20} className="text-slate-500 group-hover:text-white smooth-transition" />
              </a>
            </div>
          </m.div>
        </div>
      )}
    </AnimatePresence>
  );
};
