import { useState } from "react";
import { motion as m } from "framer-motion";
import { Section } from "./ui/Section";
import { Heading } from "./ui/Heading";
import { GlassCard } from "./ui/GlassCard";
import { content } from "@/data/content";
import { Play, Youtube, ArrowRight, ImageIcon, ExternalLink } from "lucide-react";

interface WorkSectionProps {
  onProofClick: (proof: typeof content.proofOfWork[0]) => void;
}

export const WorkSection = ({ onProofClick }: WorkSectionProps) => {
  const [playingVideos, setPlayingVideos] = useState<Record<number, boolean>>({});

  const toggleVideo = (index: number) => {
    setPlayingVideos(prev => ({ ...prev, [index]: true }));
  };

  return (
    <Section id="work">
      <Heading>Featured Work</Heading>
      <div className="grid md:grid-cols-2 gap-8 mb-24">
        {content.featuredWork.map((work, i) => (
          <m.div 
            key={i} 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.1, duration: 0.4 }}
            className="h-full gpu-accelerate"
          >
            {work.type === 'video' ? (
              <div className="h-full rounded-3xl border border-white/10 bg-card overflow-hidden flex flex-col shadow-2xl hover:border-white/20 smooth-transition">
                <div className="relative aspect-video bg-black">
                  {playingVideos[i] ? (
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${work.videoId}?autoplay=1`}
                      title={work.title}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="absolute inset-0"
                    ></iframe>
                  ) : (
                    <button
                      onClick={() => toggleVideo(i)}
                      className="absolute inset-0 w-full h-full bg-cover bg-center group cursor-pointer"
                      style={{ backgroundImage: `url(https://img.youtube.com/vi/${work.videoId}/hqdefault.jpg)` }}
                      aria-label="Play Video"
                    >
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 smooth-transition" />
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-white/10 border border-white/20 rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 smooth-transition group-hover:bg-white/20" style={{ backdropFilter: 'blur(8px)' }}>
                        <Play className="fill-white text-white ml-2" size={36} />
                      </div>
                    </button>
                  )}
                </div>
                <div className="p-10 flex-1 flex flex-col">
                  <div className="flex items-center gap-2 mb-4 text-red-400 text-xs font-bold uppercase tracking-wider">
                    <Youtube size={16} /> Video Guide
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-6 leading-tight">{work.title}</h3>
                  <div className="mt-auto pt-6 border-t border-white/5">
                    <a
                      href={work.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm font-bold text-slate-300 hover:text-white smooth-transition flex items-center gap-2 group"
                    >
                      Watch on YouTube <ArrowRight size={16} className="group-hover:translate-x-1 smooth-transition" />
                    </a>
                  </div>
                </div>
              </div>
            ) : (
              <a href={work.url} target="_blank" rel="noreferrer" className="group block h-full">
                <div className="h-full rounded-3xl border border-white/10 bg-card overflow-hidden flex flex-col hover:border-indigo-500/30 smooth-transition shadow-2xl hover:shadow-indigo-900/20">
                  <div className="relative h-72 overflow-hidden">
                    <img 
                      src={work.image} 
                      alt={work.title} 
                      className="w-full h-full object-cover smooth-transition group-hover:scale-105 opacity-90 group-hover:opacity-100" 
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-90" />
                  </div>
                  <div className="p-10 flex-1 flex flex-col relative -mt-20">
                    <div className="flex items-center gap-2 mb-4 text-indigo-400 text-xs font-bold uppercase tracking-wider bg-card/80 w-fit px-3 py-1 rounded-lg border border-white/5" style={{ backdropFilter: 'blur(8px)' }}>
                      <work.icon size={14} /> {work.label || 'Work'}
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-indigo-300 smooth-transition leading-tight">{work.title}</h3>
                    <div className="mt-auto pt-6 border-t border-white/5 flex items-center gap-2 text-sm text-slate-400 group-hover:text-white smooth-transition">
                      {work.action || 'View Details'} <ArrowRight size={16} className="group-hover:translate-x-1 smooth-transition" />
                    </div>
                  </div>
                </div>
              </a>
            )}
          </m.div>
        ))}
      </div>

      <Heading>Proof of Work</Heading>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {content.proofOfWork.map((proof, i) => {
          const isGallery = proof.isGallery;
          const hasUrl = proof.url;

          const InnerContent = (
            <div className="flex flex-col h-full items-center text-center p-8">
              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-white/10 smooth-transition">
                <proof.icon className="text-indigo-400" size={32} />
              </div>
              <div className="font-bold text-white text-lg mb-2">{proof.title}</div>
              <div className="text-sm text-slate-400 leading-relaxed">{proof.desc}</div>
              {isGallery ? (
                <div className="mt-8 flex items-center gap-2 text-xs text-white font-bold uppercase tracking-wider neon-pill px-4 py-2 hover:scale-105 smooth-transition cursor-pointer">
                  <ImageIcon size={14} /> View Gallery
                </div>
              ) : hasUrl ? (
                <div className="mt-8 flex items-center gap-2 text-xs text-white font-bold uppercase tracking-wider neon-pill px-4 py-2 hover:scale-105 smooth-transition cursor-pointer">
                  View Link <ExternalLink size={14} />
                </div>
              ) : null}
            </div>
          );

          return (
            <GlassCard
              key={i}
              delay={i * 0.05}
              className="h-full !p-0 bg-gradient-to-br from-white/[0.03] to-transparent border-white/5"
              onClick={isGallery ? () => onProofClick(proof) : undefined}
            >
              {isGallery ? (
                <div className="h-full block">{InnerContent}</div>
              ) : hasUrl ? (
                <a href={proof.url} target="_blank" rel="noreferrer" className="block h-full">{InnerContent}</a>
              ) : (
                <div className="h-full block">{InnerContent}</div>
              )}
            </GlassCard>
          );
        })}
      </div>
    </Section>
  );
};
