import { useEffect, useState, useRef } from "react";

interface TypewriterProps {
  text: string;
  startDelay?: number;
  shouldStart: boolean;
  className?: string;
  speed?: number;
  onComplete?: () => void;
  showCursor?: boolean;
}

export const Typewriter = ({
  text,
  startDelay = 0,
  shouldStart,
  className = "",
  speed = 15,
  onComplete,
  showCursor = true
}: TypewriterProps) => {
  const [displayText, setDisplayText] = useState("");
  const [isComplete, setIsComplete] = useState(false);
  const intervalRef = useRef<number | null>(null);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => {
    if (!shouldStart) return;

    // Clear any existing timers
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (intervalRef.current) clearInterval(intervalRef.current);

    timeoutRef.current = window.setTimeout(() => {
      let currentIndex = 0;
      
      intervalRef.current = window.setInterval(() => {
        if (currentIndex <= text.length) {
          setDisplayText(text.slice(0, currentIndex));
          currentIndex++;
        } else {
          if (intervalRef.current) clearInterval(intervalRef.current);
          setIsComplete(true);
          if (onComplete) onComplete();
        }
      }, speed);
    }, startDelay);

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [text, startDelay, shouldStart, speed, onComplete]);

  return (
    <p className={className}>
      {displayText}
      {showCursor && !isComplete && <span className="animate-pulse">|</span>}
    </p>
  );
};
