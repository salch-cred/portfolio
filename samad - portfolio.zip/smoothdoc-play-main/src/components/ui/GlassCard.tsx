import { motion as m } from "framer-motion";
import { ReactNode, useCallback, useState } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  onClick?: () => void;
  hoverEffect?: boolean;
}

export function GlassCard({ children, className = "", delay = 0, onClick, hoverEffect = true }: CardProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  // Throttled mouse move handler for better performance
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top } = e.currentTarget.getBoundingClientRect();
    setMousePosition({ x: e.clientX - left, y: e.clientY - top });
  }, []);

  return (
    <m.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay, duration: 0.4 }}
      onMouseMove={hoverEffect ? handleMouseMove : undefined}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      className={`group relative border border-white/10 rounded-3xl bg-white/5 overflow-hidden gpu-accelerate ${hoverEffect ? 'hover:border-white/20 hover:bg-white/10' : ''} ${onClick ? 'cursor-pointer smooth-transition hover:-translate-y-1' : ''} ${className}`}
    >
      {/* Optimized spotlight effect - only renders when hovered */}
      {hoverEffect && isHovered && (
        <div
          className="pointer-events-none absolute -inset-px opacity-100 transition-opacity duration-300"
          style={{
            background: `radial-gradient(400px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(129, 140, 248, 0.12), transparent 60%)`,
          }}
        />
      )}
      <div className="relative h-full p-8">{children}</div>
    </m.div>
  );
}
