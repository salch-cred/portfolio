import { motion as m } from "framer-motion";
import { ReactNode } from "react";

interface HeadingProps {
  children: ReactNode;
  className?: string;
  align?: "text-center" | "text-left" | "text-right";
}

export const Heading = ({ children, className = "", align = "text-center" }: HeadingProps) => (
  <m.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.5 }}
    className={`mb-16 ${align} ${className}`}
  >
    <h2 className="text-4xl md:text-6xl font-bold tracking-tight text-gradient-heading inline-block">
      {children}
    </h2>
    <div className={`h-1.5 w-24 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full mt-4 ${align === "text-center" ? "mx-auto" : ""}`} />
  </m.div>
);
