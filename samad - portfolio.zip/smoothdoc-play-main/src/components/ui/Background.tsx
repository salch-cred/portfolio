// Performance-optimized background with reduced blur and GPU acceleration
export const Background = () => (
  <div className="fixed inset-0 overflow-hidden pointer-events-none">
    {/* Optimized gradients with reduced blur (60px instead of 150px) */}
    <div 
      className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full animate-pulse-soft gpu-accelerate"
      style={{
        background: 'radial-gradient(circle, hsla(238, 84%, 40%, 0.15) 0%, transparent 70%)',
      }}
    />
    <div
      className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full animate-pulse-soft gpu-accelerate"
      style={{ 
        animationDelay: "2s",
        background: 'radial-gradient(circle, hsla(271, 81%, 40%, 0.1) 0%, transparent 70%)',
      }}
    />
    <div 
      className="absolute top-[40%] left-[30%] w-[40%] h-[40%] rounded-full gpu-accelerate"
      style={{
        background: 'radial-gradient(circle, hsla(217, 91%, 40%, 0.08) 0%, transparent 70%)',
      }}
    />
  </div>
);
