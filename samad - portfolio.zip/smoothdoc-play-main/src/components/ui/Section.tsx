import { ReactNode } from "react";

interface SectionProps {
  id?: string;
  className?: string;
  children: ReactNode;
}

export const Section = ({ id, className = "", children }: SectionProps) => (
  <section id={id} className={`py-24 px-6 relative z-10 ${className}`}>
    <div className="max-w-7xl mx-auto">{children}</div>
  </section>
);
