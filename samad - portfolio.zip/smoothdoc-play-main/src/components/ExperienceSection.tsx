import { motion as m } from "framer-motion";
import { Section } from "./ui/Section";
import { Heading } from "./ui/Heading";
import { content } from "@/data/content";

export const ExperienceSection = () => {
  return (
    <Section id="experience">
      <Heading>Experience</Heading>
      <div className="space-y-6 max-w-4xl mx-auto">
        {content.experience.map((job, i) => (
          <m.div
            key={i}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.03, duration: 0.4 }}
            className="flex flex-col md:flex-row gap-8 p-8 rounded-3xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/10 smooth-transition hover:shadow-2xl hover:shadow-black/50 group"
          >
            <div className="md:w-1/3">
              <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-indigo-300 smooth-transition">{job.company}</h3>
              <div className="inline-block px-3 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-bold uppercase tracking-wide border border-indigo-500/20">{job.role}</div>
            </div>
            <div className="md:w-2/3 border-l border-white/5 pl-8 md:border-l-white/10">
              <ul className="list-disc pl-4 space-y-2 text-slate-400 font-light leading-relaxed">
                {job.points.map((point, j) => (
                  <li key={j}>{point}</li>
                ))}
              </ul>
            </div>
          </m.div>
        ))}
      </div>
    </Section>
  );
};
