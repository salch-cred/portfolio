import { forwardRef } from "react";
import { motion as m } from "framer-motion";
import { Heading } from "./ui/Heading";
import { GlassCard } from "./ui/GlassCard";
import { Typewriter } from "./ui/Typewriter";
import { content } from "@/data/content";
import { Award, Users, Target, Shield } from "lucide-react";

interface AboutSectionProps {
  startTypewriter: boolean;
}

const stats = [
  { label: "Experience", value: "4+ Years", icon: Award },
  { label: "Communities", value: "700k+", icon: Users },
  { label: "Projects", value: "13+", icon: Target },
  { label: "Focus", value: "Retention", icon: Shield },
];

export const AboutSection = forwardRef<HTMLElement, AboutSectionProps>(
  ({ startTypewriter }, ref) => {
    return (
      <section id="about" className="py-24 px-6 relative z-10" ref={ref}>
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <m.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Heading align="text-left">About Me</Heading>
            <div className="space-y-6 text-lg leading-relaxed text-slate-400 font-light min-h-[300px]">
              {startTypewriter && (
                <>
                  <Typewriter
                    text={content.about.text1}
                    startDelay={0}
                    shouldStart={startTypewriter}
                    className="mb-4"
                    speed={12}
                  />
                  <Typewriter
                    text={content.about.text2}
                    startDelay={content.about.text1.length * 12 + 300}
                    shouldStart={startTypewriter}
                    className="mb-4"
                    speed={12}
                  />
                  <Typewriter
                    text={content.about.text3}
                    startDelay={(content.about.text1.length + content.about.text2.length) * 12 + 600}
                    shouldStart={startTypewriter}
                    className="text-slate-200 font-normal border-l-4 border-indigo-500 pl-4 mb-4"
                    speed={12}
                  />
                  <Typewriter
                    text={content.about.text4}
                    startDelay={(content.about.text1.length + content.about.text2.length + content.about.text3.length) * 12 + 900}
                    shouldStart={startTypewriter}
                    speed={12}
                  />
                </>
              )}
            </div>
          </m.div>

          <GlassCard className="!p-0 border-0 bg-transparent" hoverEffect={false}>
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <m.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.4 }}
                  className="p-8 bg-white/5 rounded-3xl border border-white/5 flex flex-col items-center text-center justify-center aspect-square hover:bg-white/10 hover:border-white/20 smooth-transition hover:-translate-y-2 hover:shadow-2xl"
                >
                  <stat.icon className="w-10 h-10 text-indigo-400 mb-4" />
                  <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                  <div className="text-xs text-slate-500 uppercase tracking-widest font-bold">{stat.label}</div>
                </m.div>
              ))}
            </div>
          </GlassCard>
        </div>
      </section>
    );
  }
);

AboutSection.displayName = "AboutSection";
