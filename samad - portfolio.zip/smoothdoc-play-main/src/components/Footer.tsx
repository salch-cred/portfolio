import { ArrowUp } from "lucide-react";

export const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  return (
    <footer className="relative z-10 py-12 text-center text-slate-500 text-sm border-t border-white/5 bg-background">
      <div className="flex flex-col items-center gap-4">
        <p>© {new Date().getFullYear()} Samad — Web3 Community Manager</p>
        <button
          onClick={scrollToTop}
          className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 smooth-transition text-xs font-bold uppercase tracking-wider"
        >
          Back to Top <ArrowUp size={14} />
        </button>
      </div>
    </footer>
  );
};
