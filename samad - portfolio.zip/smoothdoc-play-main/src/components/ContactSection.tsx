import { Section } from "./ui/Section";
import { content } from "@/data/content";

export const ContactSection = () => {
  return (
    <Section id="contact" className="py-32">
      <div className="max-w-4xl mx-auto text-center bg-gradient-to-b from-indigo-900/10 to-transparent p-12 md:p-20 rounded-[3rem] border border-white/5 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-500/10 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tight">Let's Connect</h2>
          <p className="text-xl text-slate-400 mb-16 max-w-2xl mx-auto font-light leading-relaxed">
            {content.contact.text}
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {content.contact.links.map((link, i) => {
              const Icon = link.icon;
              return (
                <a
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className="neon-link flex items-center gap-3 px-8 py-4 rounded-2xl bg-background border border-white/10 text-slate-300 hover:text-white hover:border-white/20 hover:-translate-y-1 hover:shadow-xl smooth-transition group"
                >
                  <Icon size={24} className={`smooth-transition ${link.color}`} />
                  <span className="font-bold text-sm uppercase tracking-wide">{link.label}</span>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </Section>
  );
};
