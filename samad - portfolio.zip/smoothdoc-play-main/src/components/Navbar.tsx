import { useState } from "react";
import { motion as m, AnimatePresence, MotionValue } from "framer-motion";
import { Menu, X } from "lucide-react";

interface NavbarProps {
  scaleX: MotionValue<number>;
  onHireClick: () => void;
}

const navItems = ["About", "Skills", "Experience", "Work", "Contact"];

export const Navbar = ({ scaleX, onHireClick }: NavbarProps) => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  return (
    <>
      {/* Scroll Progress Bar - optimized */}
      <m.div
        className="fixed top-0 left-0 right-0 h-1 z-50 origin-left bg-indigo-500 gpu-accelerate"
        style={{ 
          scaleX,
          boxShadow: '0 0 15px hsla(238, 84%, 67%, 0.4)'
        }}
      />

      {/* Navbar - reduced blur for clarity */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-background/90 border-b border-white/5" style={{ backdropFilter: 'blur(12px)' }}>
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <a href="#" className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">S</span>
            Samad.
          </a>

          <div className="hidden md:flex items-center gap-8 text-sm font-medium">
            {navItems.map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById(item.toLowerCase())?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-slate-400 hover:text-white smooth-transition"
              >
                {item}
              </a>
            ))}
            <button
              onClick={onHireClick}
              className="px-6 py-2.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-full smooth-transition text-xs font-bold uppercase tracking-wider shadow-lg hover:shadow-purple-500/30 hover:scale-105"
            >
              Hire Me
            </button>
          </div>

          <button
            className="md:hidden text-slate-400 hover:text-white p-2"
            onClick={() => setIsNavOpen(!isNavOpen)}
          >
            {isNavOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isNavOpen && (
            <m.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="md:hidden overflow-hidden bg-background border-b border-white/10"
            >
              <div className="flex flex-col p-6 gap-6">
                {navItems.map((item) => (
                  <a
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    onClick={(e) => {
                      e.preventDefault();
                      setIsNavOpen(false);
                      setTimeout(() => {
                        document.getElementById(item.toLowerCase())?.scrollIntoView({ behavior: 'smooth' });
                      }, 100);
                    }}
                    className="text-xl font-medium text-slate-300 hover:text-white"
                  >
                    {item}
                  </a>
                ))}
              </div>
            </m.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
};
