import { motion as m } from "framer-motion";
import { Typewriter } from "./ui/Typewriter";
import { content } from "@/data/content";

interface HeroSectionProps {
  startHeroTypewriter: boolean;
  onResumeClick: () => void;
  onConnectClick: () => void;
}

export const HeroSection = ({ startHeroTypewriter, onResumeClick, onConnectClick }: HeroSectionProps) => {
  return (
    <section id="hero" className="relative z-10 pt-40 pb-20 px-6 min-h-screen flex flex-col justify-center items-center text-center">
      <m.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl gpu-accelerate"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-bold tracking-wider mb-8 uppercase shadow-[0_0_20px_rgba(99,102,241,0.15)]">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
          </span>
          {content.hero.title}
        </div>

        <div className="mb-8 min-h-[160px] md:min-h-[220px]">
          {/* "Building Active" Text with White Pulse Glow */}
          <m.div
            animate={{ 
              textShadow: [
                "0 0 5px rgba(255,255,255,0.1)", 
                "0 0 20px rgba(255,255,255,0.4)", 
                "0 0 5px rgba(255,255,255,0.1)"
              ] 
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <Typewriter
              text="Building Active"
              startDelay={200}
              shouldStart={startHeroTypewriter}
              speed={60}
              className="text-5xl md:text-8xl font-black text-white tracking-tight leading-[1.1] drop-shadow-2xl"
              showCursor={false}
            />
          </m.div>

          {/* "Web3 Communities" Text with Moving Gradient & Hue Rotation */}
          <m.div
            animate={{
              filter: [
                "hue-rotate(0deg) drop-shadow(0 0 10px rgba(168,85,247,0.3))",
                "hue-rotate(360deg) drop-shadow(0 0 30px rgba(34,211,238,0.5))"
              ]
            }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="gpu-accelerate"
          >
            <div className="text-5xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-[length:200%_auto] pb-2">
              <Typewriter
                text="Web3 Communities."
                startDelay={1200}
                shouldStart={startHeroTypewriter}
                speed={60}
                className="inline"
                showCursor={false}
              />
            </div>
          </m.div>
        </div>

        <p className="text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed mb-12 font-light">
          {content.hero.subtext}
        </p>

        <div className="flex flex-col sm:flex-row gap-6 justify-center">
          <button
            onClick={onResumeClick}
            className="px-8 py-4 bg-white/5 hover:bg-white/10 text-white rounded-full font-medium smooth-transition border border-white/10 hover:border-white/30"
          >
            View Resume
          </button>
          <button
            onClick={onConnectClick}
            className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-medium smooth-transition shadow-[0_0_30px_rgba(79,70,229,0.3)] hover:shadow-[0_0_40px_rgba(79,70,229,0.4)] hover:-translate-y-1"
          >
            Let's Connect
          </button>
        </div>
      </m.div>
    </section>
  );
};
