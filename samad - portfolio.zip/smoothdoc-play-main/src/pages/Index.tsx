import { useEffect, useState, useRef } from "react";
import { useScroll, useSpring, useInView } from "framer-motion";
import { Background } from "@/components/ui/Background";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { AboutSection } from "@/components/AboutSection";
import { SkillsSection } from "@/components/SkillsSection";
import { ExperienceSection } from "@/components/ExperienceSection";
import { WorkSection } from "@/components/WorkSection";
import { ContactSection } from "@/components/ContactSection";
import { Footer } from "@/components/Footer";
import { GalleryModal } from "@/components/modals/GalleryModal";
import { ContactModal } from "@/components/modals/ContactModal";
import { ResumeModal } from "@/components/modals/ResumeModal";
import { content } from "@/data/content";

type ProofOfWork = typeof content.proofOfWork[0];

const Index = () => {
  const [activeProof, setActiveProof] = useState<ProofOfWork | null>(null);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [startTypewriter, setStartTypewriter] = useState(false);
  const [startHeroTypewriter, setStartHeroTypewriter] = useState(false);

  const aboutRef = useRef<HTMLElement>(null);
  const isAboutInView = useInView(aboutRef, { once: true, amount: 0.3 });

  useEffect(() => {
    // Small delay for initial render
    const timer = setTimeout(() => {
      setStartHeroTypewriter(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isAboutInView) {
      setStartTypewriter(true);
    }
  }, [isAboutInView]);

  const { scrollYProgress } = useScroll();
  // Optimized spring config - less stiff for smoother animation
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="min-h-screen bg-background text-slate-300 font-sans">
      <Background />

      <Navbar scaleX={scaleX} onHireClick={() => setIsContactOpen(true)} />

      <HeroSection
        startHeroTypewriter={startHeroTypewriter}
        onResumeClick={() => setIsResumeOpen(true)}
        onConnectClick={() => setIsContactOpen(true)}
      />

      <AboutSection ref={aboutRef} startTypewriter={startTypewriter} />

      <SkillsSection />

      <ExperienceSection />

      <WorkSection onProofClick={setActiveProof} />

      <ContactSection />

      <Footer />

      {/* Modals */}
      <GalleryModal activeProof={activeProof} onClose={() => setActiveProof(null)} />
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
      <ResumeModal isOpen={isResumeOpen} onClose={() => setIsResumeOpen(false)} />
    </div>
  );
};

export default Index;
