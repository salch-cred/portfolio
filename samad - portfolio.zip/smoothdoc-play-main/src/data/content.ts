import {
  Users,
  TrendingUp,
  PenTool,
  Wrench,
  FileText,
  Twitter,
  Youtube,
  MessageSquare,
  Linkedin,
  Mail,
  Send,
} from "lucide-react";

export const content = {
  hero: {
    name: "Samad",
    title: "Web3 Community Manager",
    headline: "I help Web3 projects turn quiet servers into active communities.",
    subtext: "Community manager with 4 years of experience growing crypto communities through real engagement, clear communication and consistent execution I've worked with projects like Galxe, Web3Go (DIN), Nolus Protocol Mantis Tyche and many others across the Web3 ecosystem.",
  },

  about: {
    text1: "I'm a Web3 community manager with over 4 years of experience building and growing crypto communities.",
    text2: "I started my journey in crypto back in 2021 and have since worked with multiple Web3 projects helping them improve engagement onboard users and create welcoming spaces for their communities.",
    text3: "I've managed communities with over 700k plus members led ambassador programs organized AMAs and campaigns, and created content that makes complex DeFi concepts easy to understand.",
    text4: "What I care about most is building real communities not just growing numbers My focus is always on activity retention and making users feel heard."
  },

  skills: [
    {
      category: "Community Management",
      icon: Users,
      items: [
        "Discord & Telegram moderation",
        "Daily engagement strategies",
        "AMAs, contests, and events",
        "Ambassador programs",
        "Ticket support and user onboarding"
      ]
    },
    {
      category: "Growth & Engagement",
      icon: TrendingUp,
      items: [
        "Zealy and Galxe campaigns",
        "Community activation plans",
        "Regional growth (India)",
        "Retention strategies",
        "Feedback collection"
      ]
    },
    {
      category: "Content",
      icon: PenTool,
      items: [
        "Medium articles",
        "Twitter content",
        "Community announcements",
        "Guides and FAQs"
      ]
    },
    {
      category: "Tools",
      icon: Wrench,
      items: [
        "Discord bots",
        "Zealy",
        "Galxe",
        "Notion",
        "Google Sheets",
        "Basic automation"
      ]
    }
  ],

  experience: [
    {
      company: "Galxe",
      role: "Community Moderator",
      desc: "Handled large-scale community moderation and user support, improved onboarding with structured FAQs, and maintained safety through rule enforcement and anti-scam workflows.",
      points: [
        "Moderated and supported a large-scale Web3 community, ensuring fast onboarding help and user support.",
        "Handled community queries professionally and reduced repeated issues using structured answers/FAQs.",
        "Maintained safety and trust through rule enforcement, spam control, and scam prevention workflows."
      ]
    },
    {
      company: "Web3Go (DIN)",
      role: "Community Manager",
      desc: "Managed Discord operations, engagement routines, and campaigns while simplifying complex DeFi topics into beginner-friendly guides.",
      points: [
        "Managed Discord operations: moderation coverage, support flow, and engagement routines.",
        "Executed campaigns/events and helped improve retention through consistent community activity.",
        "Simplified complex product/DeFi topics into beginner-friendly explanations and guides."
      ]
    },
    {
      company: "Nolus Protocol",
      role: "Community Manager",
      desc: "Created educational content, ran engagement campaigns, collected feedback, and shared insights with the team to improve community operations.",
      points: [
        "Created educational content and community updates to improve product understanding.",
        "Ran engagement activities and community campaigns to increase participation.",
        "Collected feedback, tracked sentiment, and reported insights to improve community operations."
      ]
    },
    {
      company: "Mantis",
      role: "Regional Community Manager (India)",
      desc: "Led the Indian community, hosted AMAs and contests, supported localized growth, and acted as a bridge between users and the core team.",
      points: [
        "Led localized growth strategy for India and kept community activity consistent.",
        "Hosted AMAs, contests, and community events to drive participation and retention.",
        "Acted as bridge between users and team, sharing feedback and market/community insights."
      ]
    },
    {
      company: "Tyche Protocol",
      role: "Community Manager",
      desc: "Managed daily community operations and supported the ambassador program to expand reach and participation.",
      points: [
        "Managed day-to-day community ops, moderation, engagement prompts, and user support.",
        "Supported an Ambassador Program to expand reach and increase community participation."
      ]
    },
    {
      company: "MEXC",
      role: "India KOL / BD Support",
      desc: "Supported India-focused KOL outreach, helped execute campaigns, tracked performance, and monitored regional Web3 trends.",
      points: [
        "Leading KOL and influencer outreach efforts to boost MEXC's presence and user growth in the Indian crypto market.",
        "Building and nurturing long-term relationships with local KOLs, partners, and marketing channels.",
        "Supporting the execution and performance tracking of KOL marketing campaigns.",
        "Monitoring local market trends and competitor strategies to optimize campaign impact.",
        "Staying engaged with the Indian Web3 community to keep MEXC relevant and competitive."
      ]
    },
    {
      company: "ZKDX",
      role: "Community Manager",
      desc: "Handled Discord and Telegram operations, guided onboarding, explained tasks and updates, and kept conversations active during campaigns.",
      points: [
        "Took care of day-to-day community operations across Discord and Telegram.",
        "Guided users through onboarding and explained tasks, updates, and platform basics.",
        "Kept conversations active while maintaining order during high-traffic and campaign phases."
      ]
    },
    {
      company: "Astra Nova",
      role: "Moderator",
      desc: "Maintained discipline in Discord, enforced rules, managed high-traffic channels during announcements, and removed spam/scam attempts.",
      points: [
        "Maintained discipline in Discord by enforcing rules and handling community issues calmly.",
        "Supported major announcements and campaign pushes by keeping channels clean and well-managed.",
        "Protected users by quickly spotting spam/scam attempts and removing them early."
      ]
    },
    {
      company: "Laika AI",
      role: "Community Manager",
      desc: "Kept discussions active, onboarded new users with simple explanations, and shared community feedback with the team.",
      points: [
        "Kept community discussions active and encouraged members to participate.",
        "Helped onboard new users with simple explanations and quick replies.",
        "Shared community feedback with the team to improve communication and updates."
      ]
    },
    {
      company: "Pi Squared",
      role: "Moderator",
      desc: "Focused on keeping communities safe and organized while helping users during daily discussions and key updates.",
      points: [
        "Focused on keeping the community safe, clean, and well-organized during daily discussions.",
        "Helped users with questions and repeated issues so the chat stayed clear and structured.",
        "Stayed active during key updates to maintain smooth conversation flow."
      ]
    },
    {
      company: "Liquid",
      role: "Moderator",
      desc: "Monitored chats, removed spam, assisted users during campaigns and updates, and kept announcements clear.",
      points: [
        "Monitored chats and removed spam to maintain a professional community environment.",
        "Assisted users during updates, events, and campaign phases with fast guidance.",
        "Ensured announcements and discussions remained easy to follow."
      ]
    },
    {
      company: "HyperGPT",
      role: "Community Helper",
      desc: "Helped users with tasks and troubleshooting, explained confusing topics in simple terms, and stayed active as reliable support.",
      points: [
        "Helped users with tasks, troubleshooting, and general platform questions in a friendly way.",
        "Broke down confusing topics into simple explanations for beginners.",
        "Stayed active as a reliable point of help for recurring community issues."
      ]
    },
    {
      company: "Zora",
      role: "Community Contributor",
      desc: "Supported community members, stayed active during ecosystem updates, and helped build a positive community culture.",
      points: [
        "Stayed active in discussions and supported other community members when needed.",
        "Helped increase engagement through consistent interaction during ecosystem updates.",
        "Contributed to a positive and welcoming community culture."
      ]
    }
  ],

  achievements: [
    "Grew one project's community by over 60% using daily engagement, AMAs, contests, and weekly activities",
    "Managed communities with over 1M members",
    "Successfully supported ambassador programs",
    "Improved user participation and retention across multiple projects",
    "Created educational content that helped onboard non-technical users"
  ],

  featuredWork: [
    {
      title: "Arbitrum Arc – CoW AMM Guide",
      icon: FileText,
      url: "https://medium.com/@samadsaifi403/the-arbitrum-arc-move-into-cow-amm-and-earn-big-with-50k-in-arb-rewards-87cf93a2c569",
      image: "https://miro.medium.com/v2/resize:fit:1100/format:webp/0*ne1B5LRlmhzcgMpx.png",
      label: "Article",
      action: "Read on Medium"
    },
    {
      title: "Get to Know Gems Launchpad",
      icon: Youtube,
      url: "https://youtube.com/@cryptolooters3287?si=c0bYuu_7tNuYaMm4",
      type: "video",
      videoId: "t0U0L2bb8zQ"
    },
    {
      title: "CodeAssist - Ai that's learn from you",
      icon: Twitter,
      url: "https://x.com/samadsaifi56/status/1988790827670544563?s=20",
      image: "https://pbs.twimg.com/card_img/2014325493206790145/M_ILMOiV?format=png&name=small",
      label: "Post",
      action: "View on X"
    },
    {
      title: "Swan Chain Mission: Mainnet Week 5",
      icon: FileText,
      url: "https://medium.com/@samadsaifi403/introducing-swan-chain-mission-mainnet-week-5-on-chain-dbbdaacc871d",
      image: "https://miro.medium.com/v2/resize:fit:1100/format:webp/0*w4WXV2tbXu_RjuG0",
      label: "Article",
      action: "Read on Medium"
    },
  ],

  proofOfWork: [
    {
      title: "Discord Activity",
      desc: "Examples of engagement & support",
      icon: MessageSquare,
      images: [
        "https://pbs.twimg.com/media/G_pJPNobAAIvxLF?format=png&name=small",
        "https://pbs.twimg.com/media/G_pMSaaX0AArBB8?format=png&name=small"
      ],
      isGallery: true
    },
    { title: "Medium Articles", desc: "Technical writing & guides", icon: FileText, url: "https://medium.com/@samadsaifi403" },
    { title: "Twitter Posts", desc: "Announcements & threads", icon: Twitter, url: "https://x.com/samadsaifi56" },
    {
      title: "Events Screenshots",
      desc: "Live event hosting proof",
      icon: Users,
      images: [
        "https://pbs.twimg.com/media/G_pQE0RXoAAkZBC?format=jpg&name=large",
        "https://pbs.twimg.com/media/G_pQHgVbsAA7or-?format=jpg&name=large",
        "https://pbs.twimg.com/media/G_pQMhmbcAAXVNA?format=jpg&name=large",
        "https://pbs.twimg.com/media/G_p9RsasAA_MtV?format=jpg&name=small",
        "https://pbs.twimg.com/media/G_pQ_ylbAAIAxzc?format=jpg&name=small"
      ],
      isGallery: true
    },
  ],

  contact: {
    text: "Looking for a community manager who focuses on real engagement and long-term growth? Let's connect.",
    links: [
      { label: "Twitter", icon: Twitter, url: "https://x.com/samadsaifi56", color: "text-sky-400" },
      { label: "LinkedIn", icon: Linkedin, url: "https://www.linkedin.com/in/samad-saifi-343529283", color: "text-blue-500" },
      { label: "Medium", icon: FileText, url: "https://medium.com/@samadsaifi403", color: "text-white" },
      { label: "YouTube", icon: Youtube, url: "https://youtube.com/@cryptolooters3287?si=c0bYuu_7tNuYaMm4", color: "text-red-500" },
      { label: "Telegram", icon: Send, url: "https://t.me/samadsaifi55", color: "text-sky-300" },
      { label: "Email", icon: Mail, url: "mailto:samadsaifi304@gmail.com", color: "text-indigo-400" },
    ]
  }
};
