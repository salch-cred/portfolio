# Open Graph Image Setup

The project now references an Open Graph image at `https://samad.lol/og-image.png`

This image will be displayed when your website is shared on social media platforms like:
- Discord
- Twitter/X
- Facebook
- LinkedIn
- WhatsApp
- Slack

## How to Create Your OG Image

### Option 1: Use an Online Tool (Easiest)

Use these free tools to create a professional OG image:
- **Canva**: https://www.canva.com (1200x630px template)
- **Figma**: Create a 1200x630px frame
- **OG Image Generator**: https://og-image.vercel.app

### Option 2: Design Specifications

**Recommended Size**: 1200 x 630 pixels
**Format**: PNG or JPG
**Max File Size**: 5-8 MB (smaller is better)
**Aspect Ratio**: 1.91:1

**What to Include:**
- Your name: "Samad"
- Your title: "Software Engineer"
- A clean, professional design
- Your personal branding/colors
- Optional: Logo or avatar

### Option 3: Quick Template

Here's what your OG image could contain:

```
┌──────────────────────────────────────┐
│                                      │
│           SAMAD                      │
│      Software Engineer               │
│                                      │
│    Building innovative solutions     │
│         samad.lol                    │
│                                      │
└──────────────────────────────────────┘
```

## How to Add Your OG Image

### Method 1: Add to Public Folder (Recommended)

1. Create your OG image (1200x630px)
2. Name it: `og-image.png`
3. Place it in: `public/og-image.png`
4. That's it! The path `/og-image.png` will work automatically

### Method 2: Update the Meta Tags

If you want to use a different filename or external URL, update `index.html`:

```html
<meta property="og:image" content="https://samad.lol/your-image.png" />
<meta name="twitter:image" content="https://samad.lol/your-image.png" />
```

## Testing Your OG Image

After deploying, test how your link looks:

**Discord**: Just paste the link in a channel
**Twitter**: Use Twitter Card Validator: https://cards-dev.twitter.com/validator
**Facebook**: Use Facebook Debugger: https://developers.facebook.com/tools/debug/
**LinkedIn**: Post a test and preview
**General Tool**: https://www.opengraph.xyz/

## Current Status

⚠️ **Action Required**: You need to create and add an `og-image.png` file to the `public/` folder.

Without this image, social media platforms will show a broken image or no preview.

## Quick Fix (Temporary)

If you want to deploy immediately without a custom image, you can:

1. Use placeholder.svg that's already in public folder
2. Update meta tags to:
```html
<meta property="og:image" content="https://samad.lol/placeholder.svg" />
```

But creating a proper OG image is highly recommended for a professional appearance!

## Tips

- Keep text large and readable (even at small sizes)
- Use high contrast
- Avoid small details
- Test on dark and light backgrounds
- Brand consistently with your site colors
- Update favicon.ico while you're at it!
